package Api;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
 


public class Create extends HttpServlet {

    private PrintWriter out;

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        response.setHeader("Cache-Control","no-cache");
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // Recepcion de datos de la pagina web
        String idc=request.getParameter("id");
        String RGB=request.getParameter("RGB");
        String R=request.getParameter("R");
        String G=request.getParameter("G");
        String B=request.getParameter("B");
        String Pred=request.getParameter("Pred");
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            StringBuilder json = new StringBuilder();
            json.append("[");      
      String result;   
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      //Query del create
      String Query="INSERT INTO COLORS(columncolors) values('{\"id\" :\""+idc+"\",\"RGB\" :\""+RGB+"\",\"R\" :\""+R+"\",\"G\" :\""+G+"\",\"B\" :\""+B+"\",\"PREDICTION\" :\""+Pred+"\"}');";   
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    try{
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // INstancia del objeto
        DB bd= new DB();
        bd.setConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost/dbcolors");
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
            //SE ejecuta la actualizacion y se envia mensaje si se pudo o no insertar los elementos
        int i=bd.executeUpdate(Query);
        if(i>0){
            result="Se inserto la query ";
            out.write(result);
        } else{
            result="Se murio la query ";
            out.write(result);
        }  
       }
    catch(SQLException e){
    e.printStackTrace();
    }
   //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    
    }
}
