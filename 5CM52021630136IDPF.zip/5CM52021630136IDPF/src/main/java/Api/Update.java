package Api;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
 


public class Update extends HttpServlet {

    private PrintWriter out;

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        out = response.getWriter();
        response.setHeader("Cache-Control","no-cache");
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //Se reciben los parametros de la pagina web
        String curId=request.getParameter("curId");
        String idu=request.getParameter("id");
        String RGBu=request.getParameter("RGB");
        String Ru=request.getParameter("R");
        String Gu=request.getParameter("G");
        String Bu=request.getParameter("B");
        String Predu=request.getParameter("Pred");
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            StringBuilder json = new StringBuilder();
            json.append("[");      
      String result;
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      //Query para actualizar
      String Query="UPDATE COLORS SET columncolors ='{\"id\" :\""+idu+"\",\"RGB\" :\""+RGBu+"\",\"R\" :\""+Ru+"\",\"G\" :\""+Gu+"\",\"B\" :\""+Bu+"\",\"PREDICTION\" :\""+Predu+"\"}' WHERE JSON_EXTRACT(columncolors,'$.id')="+"'"+curId+"';";      
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    try{
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //Instancia de Bd
       DB bd= new DB();
        bd.setConnection("com.mysql.cj.jdbc.Driver", "jdbc:mysql://localhost/dbcolors");
      //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
      //Se ejecuta la actualizacion en bd y se manda mensaje si fue posible o no
      int i=bd.executeUpdate(Query);
        if(i>0){
            result="Se inserto la query pa";
            out.write(result);
        } else{
            result="Se murio la query pa";
            out.write(result);
        }  
       }
    catch(SQLException e){
    e.printStackTrace();
    }
    //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    
    }
}